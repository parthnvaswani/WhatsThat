//make a string of curse words for regex
let str, regex;
chrome.storage.local.get("curse", function (result) {
  if (result["curse"]) {
    let json = JSON.parse(result["curse"]);

    curseWords = [...curseWords, ...json.words];
  }
  str = curseWords.join("|").replace(/[-\/\\^$*+?.()[\]{}]/g, "\\$&");

  regex = new RegExp(str, "gi");
});
chrome.storage.local.get("slang", function (result) {
  if (result["slang"]) {
    let json = JSON.parse(result["slang"]);

    slangs = { ...slangs, ...json.words };
  }
});

let button = document.createElement("button");
button.setAttribute("draggable", "true");
button.style.top = "91.5vh";
button.style.left = "88vw";
button.innerText = "filter";
button.classList.add("filterText");
button.addEventListener("dragstart", (e) => {
  e.target.style.opacity = "0.1";
});

button.addEventListener("dragend", (e) => {
  e.target.style.top = e.y + "px";
  e.target.style.left = e.x + "px";
  e.target.style.opacity = "1";
  e.target.style.transform = "translate(-50%,-50%)";
});
button.addEventListener("click", () => {
  let textbox = document.querySelectorAll(
    '._3FRCZ.copyable-text.selectable-text[contenteditable="true"]'
  )[1];
  if (!textbox) return;
  let message = textbox.innerText;
  let words = [];
  nlp
    .tokenize(message)
    .out("tags")
    .forEach((e) => Object.keys(e).forEach((j) => words.push(j)));
  let content = words.map((e) =>
    slangs[e.toLowerCase()] ? slangs[e.toLowerCase()] : e
  );

  let filtered = content.join(" ").replace(regex, "***");
  textbox.innerText = filtered;
});

setTimeout(() => {
  document.body.appendChild(button);
}, 8000);

chrome.runtime.sendMessage({ todo: "showPageAction" });
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.todo == "filterContent") {
    document
      .querySelectorAll(
        "span._3Whw5.selectable-text:not(.matched-mention)>span:not(._5h6Y_):not(._3Whw5)"
      )
      .forEach((e) => {
        if (!e.querySelector("a")) {
          let message = e.textContent;
          let filtered = message.replace(regex, "***");
          e.textContent = filtered;
        }
      });
  } else if (request.todo == "refineContent") {
    document
      .querySelectorAll(
        "span._3Whw5.selectable-text:not(.matched-mention)>span:not(._5h6Y_)"
      )
      .forEach((e) => {
        if (!e.querySelector("a")) {
          let words = [];
          nlp
            .tokenize(e.textContent)
            .out("tags")
            .forEach((e) => Object.keys(e).forEach((j) => words.push(j)));
          let content = words.map((e) =>
            slangs[e.toLowerCase()] ? slangs[e.toLowerCase()] : e
          );
          e.textContent = content.join(" ");
        }
      });
  }
});
